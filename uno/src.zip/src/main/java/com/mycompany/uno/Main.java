
package com.mycompany.uno;

/**
 * It is the main driver code.
 * @author Jhoseph
 */
public class Main {
    public static void main(String[] args) throws Exception {
        new Menu().setVisible(true);
    }
}
