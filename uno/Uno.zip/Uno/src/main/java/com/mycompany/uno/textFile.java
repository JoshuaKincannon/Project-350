package com.mycompany.uno;

import java.io.*;

/**
 * Class in charge of creating a file or modifying an existing txt file with names and scores of winning players
 * @author Jhoseph
 */
public class textFile {
    
    public static void saveToFile(String name, int score) {
            
        try {
            File f = new File("out.txt");          //Creates a File object called f
            FileWriter fw = new FileWriter(f);              //Creates a FileWriter object called fw
            PrintWriter pw = new PrintWriter(fw);           //Creates a PrintWriter object called pw

            pw.println(name + ", " + score);

            fw.close();
            pw.close();
        } catch(IOException e) {
            System.out.println("Error: saveToFile");
        }
    }
    
    public static void main (String args[]) {
        
        System.out.println("saveToFile was successful!");
    }
}
