package com.mycompany.uno;

import org.junit.jupiter.api.Test;
import javax.swing.*;
import static org.junit.Assert.assertEquals;

public class UnoTest {

    //JFrame frame;
    //Menu menuFrame = new Menu();
    //Main mainF = new Main();

    public UnoTest() {

    }


    @Test
    //Check if Uno game displays the AddPlayerNames form when the user presses the Start Game button.
    void requirement35() {

        /*
        JFrame menu = new Menu();
        mainF.callMenu();
        boolean actual = false;

        if(menu != null) {
            actual = true;
        }

        assertEquals(true, actual);
        */

        Menu menu = new Menu();
        new Menu().setVisible(true);

    }
}
