package com.company;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.List;
import javax.swing.*;


public class Tic {
    static ArrayList<Integer> playerPositions = new ArrayList<Integer>();
    static ArrayList<Integer> cpuPositions = new ArrayList<Integer>();
    static String playerLetter = "";

    public static void main(String[] args) {
	// write your code here

        Scanner sc = new Scanner(System.in);
        System.out.println("Insert letter to be used as TicTacToe piece, [Aa-Zz]: ");
        playerLetter = sc.next();

        char [][] GameBoard = {{' ', '|', ' ', '|', ' '},
                {'-', '*', '-', '*', '-'},
                {' ', '|', ' ', '|', ' '},
                {'-', '*', '-', '*', '-'},
                {' ', '|', ' ', '|', ' '}};
        printGameBoard(GameBoard);

        while(true) {
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter your placement, [1-9]: ");
            int playerPos = scan.nextInt();
            //check if int is actually int with if statement below:

            while (playerPositions.contains(playerPos) || cpuPositions.contains(playerPos)) {
                System.out.println("Position unavailable, choose another one: ");
                playerPos = scan.nextInt();
            }
            //System.out.println(playerPos);

            //play piece for player
            placePiece(GameBoard, playerPos, "player");
            //check winner after placing piece for player
            String gameResult = checkWinner();
            if (gameResult.length() > 0) {
                printGameBoard(GameBoard);
                System.out.println(gameResult);
                break;
            }

            //Play random for cpu
            Random rand = new Random();
            int cpuPos = rand.nextInt(9) + 1;
            while (playerPositions.contains(cpuPos) || cpuPositions.contains(cpuPos)) {
                System.out.println("Position unavailable, choose another one: ");
                cpuPos = rand.nextInt(9) + 1;
            }
            placePiece(GameBoard, cpuPos, "cpu");

            //print board
            printGameBoard(GameBoard);

            //check winner after placing cpu piece
            gameResult = checkWinner();
            if (gameResult.length() > 0) {
                printGameBoard(GameBoard);
                System.out.println(gameResult);
                break;
            }

            System.out.println(gameResult);
        }
        }


    public static void printGameBoard(char[][] GameBoard){
        for(char[] row :  GameBoard){
            for(char q : row){
                System.out.print(q);
            }
            System.out.println();
        }
    }

    public static void placePiece(char[][]GameBoard, int pos, String user){
        char letter = ' ';
            if(user.equals("player")){
                letter = playerLetter.charAt(0);
            //letter = 'G';
            playerPositions.add(pos);
            }
            else if (user.equals("cpu")){
                letter = 'V';
                cpuPositions.add(pos);
            }
        switch(pos){ //based on positions of board, print letter
            case 1:
                GameBoard[0][0] = letter;
                break;
            case 2:
                GameBoard[0][2] = letter;
                break;
            case 3:
                GameBoard[0][4] = letter;
                break;
            case 4:
                GameBoard[2][0] = letter;
                break;
            case 5:
                GameBoard[2][2] = letter;
                break;
            case 6:
                GameBoard[2][4] = letter;
                break;
            case 7:
                GameBoard[4][0] = letter;
                break;
            case 8:
                GameBoard[4][2] = letter;
                break;
            case 9:
                GameBoard[4][4] = letter;
                break;
            default:
                break;
        }
    }

    public static String checkWinner(){
        List topRow = Arrays.asList(1, 2, 3);
        List midRow = Arrays.asList(4, 5, 6);
        List bottRow = Arrays.asList(7, 8, 9);
        List leftCol = Arrays.asList(1, 4, 7);
        List midCol = Arrays.asList(2, 5, 8);
        List rightCol = Arrays.asList(3, 6, 9);
        List crossUp = Arrays.asList(7, 5, 3);
        List crossDown = Arrays.asList(1, 5, 9);

        List<List> winningConditions = new ArrayList<List>();
        winningConditions.add(topRow);
        winningConditions.add(midRow);
        winningConditions.add(bottRow);
        winningConditions.add(leftCol);
        winningConditions.add(midCol);
        winningConditions.add(rightCol);
        winningConditions.add(crossUp);
        winningConditions.add(crossDown);

        for(List w : winningConditions){
            if(playerPositions.containsAll(w)){
                return "Congratulations! You Win!";
            }
            else if (cpuPositions.containsAll(w)){
                return "CPU Wins! Better Luck Next time :(";
            }
        }
        if (playerPositions.size() + cpuPositions.size() == 9){
            return "It's a tie! Good Job!";
        }
        return "";
    }
}